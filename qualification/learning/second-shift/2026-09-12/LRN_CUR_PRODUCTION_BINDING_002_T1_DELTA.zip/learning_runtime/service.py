from __future__ import annotations
import copy
from typing import Any, Dict, Optional

from learning_core.engine import LearningEngine
from learning_core.baseline_diagnostic import BaselineDiagnosticDirector
from shared_ports.codec import digest
from .adaptive_entry import AdaptiveEntryExecutor

class LearningCommandError(ValueError):
    pass

class LearningRuntime:
    """LRN-CMD/QRY bounded canonical adapter over the previously-qualified learner kernel."""
    def __init__(self, repo, curriculum_query_port, scorer=None, curriculum_command_port=None):
        self.repo=repo
        self.curriculum=curriculum_query_port
        self.curriculum_command=curriculum_command_port
        reader=lambda course_id,version=1:self.curriculum.get_course(course_id,version)
        self.engine=LearningEngine(repo,course_reader=reader)
        self.diagnostic=BaselineDiagnosticDirector(repo,scorer=scorer,course_reader=reader)
        self.adaptive_entry=AdaptiveEntryExecutor(repo=repo,curriculum_query=curriculum_query_port,curriculum_command=curriculum_command_port,engine=self.engine,diagnostic=self.diagnostic,create_need=self.create_remediation_need,accept_plan_ref=self.accept_curriculum_plan_ref)

    def register_goal(self, *, operation_id: str, goal_id: str, title: str, desired_outcome: str, horizon: Any = None, priority: Any = None) -> Dict[str, Any]:
        payload={"goal_id":goal_id,"title":title,"desired_outcome":desired_outcome}
        if horizon is not None: payload["horizon"]=copy.deepcopy(horizon)
        if priority is not None: payload["priority"]=copy.deepcopy(priority)
        prior=self.repo.operation_result(operation_id,payload)
        if prior:return prior
        body={**payload,"owner":"MOD-LEARNING-001"}
        existing=self.repo.get_object("goal",goal_id,1)
        if existing is not None and digest(existing)!=digest(body):
            raise LearningCommandError("LEARNING_GOAL_IDENTITY_COLLISION")
        result={"goal_ref":{"goal_id":goal_id,"goal_digest":digest(body)},"goal":copy.deepcopy(body)}
        atomic=getattr(self.repo,"atomic_mutation",None)
        supports=getattr(self.repo,"supports_atomic_mutation",lambda:False)()
        if atomic is not None and supports:
            return atomic(
                operation_id=operation_id, payload=payload,
                object_write={"kind":"goal","object_id":goal_id,"version":1,"body":body},
                result=result, event=None,
            )
        if existing is None:self.repo.put_object("goal",goal_id,1,body)
        self.repo.record_operation(operation_id,payload,result)
        return result

    def create_remediation_need_contract(self, *, operation_id: str, goal_id: str, skill_or_criterion_refs: list, evidence_refs: list, diagnosis_reason: Any) -> Dict[str, Any]:
        """Exact I016-L contract surface without inventing Curriculum content or mastery.

        Evidence remains references only. The resulting Learning object records a diagnosed
        instructional need; Curriculum retains authority for the instructional response.
        """
        payload={
            "goal_id":goal_id,
            "skill_or_criterion_refs":copy.deepcopy(skill_or_criterion_refs),
            "evidence_refs":copy.deepcopy(evidence_refs),
            "diagnosis_reason":copy.deepcopy(diagnosis_reason),
        }
        prior=self.repo.operation_result(operation_id,payload)
        if prior:return prior
        if not skill_or_criterion_refs: raise LearningCommandError("REMEDIATION_TARGET_REFS_REQUIRED")
        if not evidence_refs: raise LearningCommandError("REMEDIATION_EVIDENCE_REFS_REQUIRED")
        identity_material={"goal_id":goal_id,"targets":skill_or_criterion_refs,"evidence_refs":evidence_refs,"diagnosis_reason":diagnosis_reason}
        need_id=f"RNEED-{goal_id}-{digest(identity_material)[:20]}"
        need={
            "need_id":need_id,"version":1,"owner":"MOD-LEARNING-001","goal_id":goal_id,
            "skill_or_criterion_refs":copy.deepcopy(skill_or_criterion_refs),
            "evidence_refs":copy.deepcopy(evidence_refs),
            "diagnosis_reason":copy.deepcopy(diagnosis_reason),
            "requested_outcome":"CURRICULUM_REMEDIATION_PLAN",
        }
        existing=self.repo.get_object("remediation_need",need_id,1)
        if existing is not None and digest(existing)!=digest(need):
            raise LearningCommandError("REMEDIATION_NEED_IDENTITY_COLLISION")
        result={"remediation_need_ref":{"need_id":need_id,"need_digest":digest(need)},"need":copy.deepcopy(need)}
        event={"event_type":"RemediationNeedCreated","subject_id":need_id,"body":{"goal_id":goal_id,"target_refs":copy.deepcopy(skill_or_criterion_refs),"evidence_refs":copy.deepcopy(evidence_refs)}}
        atomic=getattr(self.repo,"atomic_mutation",None)
        supports=getattr(self.repo,"supports_atomic_mutation",lambda:False)()
        if atomic is not None and supports:
            return atomic(
                operation_id=operation_id,payload=payload,
                object_write={"kind":"remediation_need","object_id":need_id,"version":1,"body":need},
                result=result,event=event,
            )
        if existing is None:self.repo.put_object("remediation_need",need_id,1,need)
        self.repo.record_operation(operation_id,payload,result)
        self.repo.emit(event["event_type"],event["subject_id"],event["body"])
        return result

    def create_remediation_need(self, *, operation_id: str, diagnostic_id: str, next_action: Dict[str, Any], crash_after_phase: Optional[str]=None) -> Dict[str, Any]:
        if next_action.get("action_type")!="TARGETED_REMEDIATION": raise LearningCommandError("REMEDIATION_NEED_REQUIRES_TARGETED_REMEDIATION_ACTION")
        diag=self.repo.get_object("baseline_diagnostic",diagnostic_id,1)
        if not diag: raise LearningCommandError("DIAGNOSTIC_NOT_FOUND")
        payload={"diagnostic_id":diagnostic_id,"next_action":copy.deepcopy(next_action)}
        prior=self.repo.operation_result(operation_id,payload)
        if prior:return prior
        need_id=f"RNEED-{diagnostic_id}-{next_action['skill_id']}"
        need={
            "need_id":need_id,"version":1,"owner":"MOD-LEARNING-001",
            "learner_id":diag["learner_id"],"diagnostic_id":diagnostic_id,
            "course_id":diag["course_id"],"course_version":diag["course_version"],"course_digest":diag["course_digest"],
            "skill_id":next_action["skill_id"],"reason_codes":list(next_action.get("reason_codes",[])),
            "diagnostic_evidence_refs":[{"probe_id":self._latest_probe_id(diagnostic_id,next_action["skill_id"])}],
            "requested_outcome":"CURRICULUM_REMEDIATION_PLAN",
        }
        existing=self.repo.get_object("remediation_need",need_id,1)
        if existing and digest(existing)!=digest(need): raise LearningCommandError("REMEDIATION_NEED_IDENTITY_COLLISION")
        if not existing:self.repo.put_object("remediation_need",need_id,1,need)
        if crash_after_phase=="NEED_STORED":
            from shared_ports.errors import InjectedCrash
            raise InjectedCrash("crash after remediation need stored")
        result={"need":copy.deepcopy(need),"need_digest":digest(need)}
        self.repo.record_operation(operation_id,payload,result)
        self.repo.emit("RemediationNeedCreated",need_id,{"diagnostic_id":diagnostic_id,"skill_id":next_action["skill_id"]})
        return result

    def accept_curriculum_plan_ref(self, *, operation_id: str, plan: Dict[str, Any], plan_digest: str) -> Dict[str, Any]:
        if plan.get("owner")!="MOD-CURRICULUM-001" or digest(plan)!=plan_digest: raise LearningCommandError("INVALID_CURRICULUM_PLAN_REF")
        need_ref=plan.get("need_ref",{})
        need=self.repo.get_object("remediation_need",need_ref.get("need_id",""),1)
        if not need or digest(need)!=need_ref.get("need_digest"): raise LearningCommandError("REMEDIATION_PLAN_NEED_REF_MISMATCH")
        payload={"plan_id":plan["plan_id"],"plan_digest":plan_digest}
        prior=self.repo.operation_result(operation_id,payload)
        if prior:return prior
        ref_id="CPLANREF-"+plan["plan_id"]
        ref={"ref_id":ref_id,"owner":"MOD-LEARNING-001","curriculum_plan_id":plan["plan_id"],"curriculum_plan_version":int(plan.get("version",1)),"curriculum_plan_digest":plan_digest,"course_id":plan["course_id"],"course_version":int(plan.get("course_version",1)),"skill_id":plan["skill_id"]}
        self.repo.put_object("curriculum_plan_ref",ref_id,1,ref)
        result={"accepted_plan_ref":copy.deepcopy(ref)}
        self.repo.record_operation(operation_id,payload,result)
        return result

    def _latest_probe_id(self, diagnostic_id: str, skill_id: str) -> str:
        index_id=f"{diagnostic_id}:{skill_id}"
        version=1; latest=None
        while True:
            row=self.repo.get_object("diagnostic_probe_index",index_id,version)
            if not row:break
            latest=row;version+=1
        if not latest: raise LearningCommandError("DIAGNOSTIC_PROBE_REQUIRED")
        return str(latest["probe_id"])
