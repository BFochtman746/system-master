from __future__ import annotations
from typing import Any, Dict, Optional

LEARNING = "MOD-LEARNING-001"
CURRICULUM = "MOD-CURRICULUM-001"

LEARNING_OBJECT_KINDS = frozenset({
    "goal", "baseline_diagnostic", "diagnostic_probe", "diagnostic_probe_index",
    "remediation_need", "curriculum_plan_ref", "adaptive_decision_trace", "learner_state_migration_plan",
    "capability_evidence_dossier", "portfolio_evidence_handoff", "workplace_evaluation",
    "workplace_scenario", "workplace_submission", "role_evidence_snapshot", "role_gap_plan",
    "role_portfolio_handoff", "role_requirement_coverage",
})
CURRICULUM_OBJECT_KINDS = frozenset({
    "course", "course_validation", "remediation_plan", "maintenance_task", "transfer_task",
    "course_activation", "course_semantic_diff", "professional_quality_report",
    "successor_validation", "successor_readiness", "standard_aligned_assessment_blueprint",
    "standard_module_alignment", "standard_module_phase", "certification_readiness_blueprint",
    "external_requirement_mapping_plan", "external_requirement_set", "external_standard",
    "external_standard_ingest_phase", "standard_freshness_contract",
})
LEARNING_EVENTS = frozenset({
    "BaselineDiagnosticCreated", "BaselineDiagnosticProbeObserved", "RemediationNeedCreated",
    "PracticeOrAssessmentEvidenceReceived", "MasteryChanged", "LearningSessionStarted",
    "LearningSessionCompleted", "AdaptiveNextActionSelected", "MaintenanceEvidenceReceived",
    "TransferEvidenceReceived", "TutorTurnCompleted",
})
CURRICULUM_EVENTS = frozenset({
    "CurriculumGenerated", "RemediationPlanCreated", "DomainGeneralCurriculumGenerated",
    "ResearchGroundedCurriculumGenerated", "OpenGoalCurriculumGenerated",
    "LiveReplayOpenGoalCourseGenerated", "StochasticCandidateSelectedAndCourseGenerated",
    "MultiCandidateSelectionAbstained", "CourseRefreshSuccessorReadyForReview", "CourseVersionActivated",
})

class AuthorityBoundaryError(PermissionError):
    pass

class OwnerScopedRepository:
    """Owner-scoped adapter around the historical Lab repository.

    It deliberately exposes no connect()/SQL handle. New canonical domain code must use this
    adapter. Historical learning_lab remains compatibility-only and is qualified separately.
    """
    __slots__ = ("__repo", "owner")

    def __init__(self, repo: Any, owner: str):
        if owner not in {LEARNING, CURRICULUM}:
            raise ValueError("UNKNOWN_DOMAIN_AUTHORITY")
        self.__repo = repo
        self.owner = owner

    def _allowed_object_kind(self, kind: str) -> bool:
        return kind in (LEARNING_OBJECT_KINDS if self.owner == LEARNING else CURRICULUM_OBJECT_KINDS)

    def _deny(self, surface: str, detail: str = "") -> None:
        suffix = f":{detail}" if detail else ""
        raise AuthorityBoundaryError(f"FOREIGN_AUTHORITY_WRITE_BLOCKED:{self.owner}:{surface}{suffix}")

    # Owner-scoped generic object store.
    def put_object(self, kind: str, object_id: str, version: int, body: Dict[str, Any]):
        if not self._allowed_object_kind(kind):
            self._deny("OBJECT", kind)
        return self.__repo.put_object(kind, object_id, version, body)

    def append_object_version_checked(self, kind: str, object_id: str, body: Dict[str, Any], expected_latest_version: Optional[int]):
        if not self._allowed_object_kind(kind):
            self._deny("OBJECT", kind)
        return self.__repo.append_object_version_checked(kind, object_id, body, expected_latest_version)

    def get_object(self, kind: str, object_id: str, version: int = 1):
        # Same-store reads only. Cross-domain reads must arrive as port values, not store access.
        if not self._allowed_object_kind(kind):
            raise AuthorityBoundaryError(f"FOREIGN_AUTHORITY_READ_REQUIRES_PORT:{self.owner}:OBJECT:{kind}")
        return self.__repo.get_object(kind, object_id, version)

    def get_latest_object(self, kind: str, object_id: str):
        if not self._allowed_object_kind(kind):
            raise AuthorityBoundaryError(f"FOREIGN_AUTHORITY_READ_REQUIRES_PORT:{self.owner}:OBJECT:{kind}")
        return self.__repo.get_latest_object(kind, object_id)

    def latest_object_version(self, kind: str, object_id: str):
        if not self._allowed_object_kind(kind):
            raise AuthorityBoundaryError(f"FOREIGN_AUTHORITY_READ_REQUIRES_PORT:{self.owner}:OBJECT:{kind}")
        return self.__repo.latest_object_version(kind, object_id)

    # Learning-only canonical learner state.
    def put_attempt(self, *args, **kwargs):
        if self.owner != LEARNING: self._deny("ATTEMPT")
        return self.__repo.put_attempt(*args, **kwargs)
    def attempts_for_skill(self, *args, **kwargs):
        if self.owner != LEARNING: raise AuthorityBoundaryError("FOREIGN_AUTHORITY_READ_REQUIRES_PORT:MOD-CURRICULUM-001:ATTEMPT")
        return self.__repo.attempts_for_skill(*args, **kwargs)
    def count_attempts(self, *args, **kwargs):
        if self.owner != LEARNING: raise AuthorityBoundaryError("FOREIGN_AUTHORITY_READ_REQUIRES_PORT:MOD-CURRICULUM-001:ATTEMPT")
        return self.__repo.count_attempts(*args, **kwargs)
    def append_projection(self, *args, **kwargs):
        if self.owner != LEARNING: self._deny("MASTERY_PROJECTION")
        return self.__repo.append_projection(*args, **kwargs)
    def latest_projection(self, *args, **kwargs):
        if self.owner != LEARNING: raise AuthorityBoundaryError("FOREIGN_AUTHORITY_READ_REQUIRES_PORT:MOD-CURRICULUM-001:MASTERY_PROJECTION")
        return self.__repo.latest_projection(*args, **kwargs)
    def projection_history(self, *args, **kwargs):
        if self.owner != LEARNING: raise AuthorityBoundaryError("FOREIGN_AUTHORITY_READ_REQUIRES_PORT:MOD-CURRICULUM-001:MASTERY_PROJECTION")
        return self.__repo.projection_history(*args, **kwargs)
    def save_tutor_turn(self, *args, **kwargs):
        if self.owner != LEARNING: self._deny("TUTOR_TURN")
        return self.__repo.save_tutor_turn(*args, **kwargs)
    def get_tutor_turn(self, *args, **kwargs):
        if self.owner != LEARNING: raise AuthorityBoundaryError("FOREIGN_AUTHORITY_READ_REQUIRES_PORT:MOD-CURRICULUM-001:TUTOR_TURN")
        return self.__repo.get_tutor_turn(*args, **kwargs)
    def completed_tutor_turns(self, *args, **kwargs):
        if self.owner != LEARNING: raise AuthorityBoundaryError("FOREIGN_AUTHORITY_READ_REQUIRES_PORT:MOD-CURRICULUM-001:TUTOR_TURN")
        return self.__repo.completed_tutor_turns(*args, **kwargs)
    def count_tutor_turns(self, *args, **kwargs):
        if self.owner != LEARNING: raise AuthorityBoundaryError("FOREIGN_AUTHORITY_READ_REQUIRES_PORT:MOD-CURRICULUM-001:TUTOR_TURN")
        return self.__repo.count_tutor_turns(*args, **kwargs)
    def save_learning_session(self, *args, **kwargs):
        if self.owner != LEARNING: self._deny("LEARNING_SESSION")
        return self.__repo.save_learning_session(*args, **kwargs)
    def get_learning_session(self, *args, **kwargs):
        if self.owner != LEARNING: raise AuthorityBoundaryError("FOREIGN_AUTHORITY_READ_REQUIRES_PORT:MOD-CURRICULUM-001:LEARNING_SESSION")
        return self.__repo.get_learning_session(*args, **kwargs)
    def sessions_for_learner(self, *args, **kwargs):
        if self.owner != LEARNING: raise AuthorityBoundaryError("FOREIGN_AUTHORITY_READ_REQUIRES_PORT:MOD-CURRICULUM-001:LEARNING_SESSION")
        return self.__repo.sessions_for_learner(*args, **kwargs)
    def save_director_decision(self, *args, **kwargs):
        if self.owner != LEARNING: self._deny("DIRECTOR_DECISION")
        return self.__repo.save_director_decision(*args, **kwargs)
    def get_director_decision(self, *args, **kwargs):
        if self.owner != LEARNING: raise AuthorityBoundaryError("FOREIGN_AUTHORITY_READ_REQUIRES_PORT:MOD-CURRICULUM-001:DIRECTOR_DECISION")
        return self.__repo.get_director_decision(*args, **kwargs)

    # Domain-local idempotency receipts are physically isolated by database.
    def operation_result(self, *args, **kwargs): return self.__repo.operation_result(*args, **kwargs)
    def record_operation(self, *args, **kwargs): return self.__repo.record_operation(*args, **kwargs)

    def supports_atomic_mutation(self) -> bool:
        return callable(getattr(self.__repo, "atomic_mutation", None))

    def atomic_mutation(self, *, operation_id: str, payload: Dict[str, Any], object_write: Dict[str, Any], result: Dict[str, Any], event: Optional[Dict[str, Any]] = None):
        """Owner-checked bridge to the DATA-001 atomic object+receipt+outbox unit.

        The semantic owner remains Learning/Curriculum. Physical transaction authority remains
        the injected production persistence adapter. Historical Lab repositories do not gain
        this authority merely because this method exists.
        """
        kind = str(object_write.get("kind", ""))
        if not self._allowed_object_kind(kind):
            self._deny("OBJECT", kind)
        if event is not None:
            event_type = str(event.get("event_type", ""))
            allowed = LEARNING_EVENTS if self.owner == LEARNING else CURRICULUM_EVENTS
            if event_type not in allowed:
                self._deny("EVENT", event_type)
        fn = getattr(self.__repo, "atomic_mutation", None)
        if fn is None:
            raise AuthorityBoundaryError(f"ATOMIC_MUTATION_BACKEND_REQUIRED:{self.owner}")
        return fn(operation_id=operation_id, payload=payload, object_write=object_write, result=result, event=event)

    # Durable jobs belong to shared Job authority, never either domain store.
    def save_job(self, *args, **kwargs): self._deny("DURABLE_JOB")
    def get_job(self, *args, **kwargs): raise AuthorityBoundaryError(f"FOREIGN_AUTHORITY_READ_REQUIRES_PORT:{self.owner}:DURABLE_JOB")

    # Domain events may be staged locally as outbox-adapter evidence only.
    def emit(self, event_type: str, subject_id: str, body: Dict[str, Any]):
        allowed = LEARNING_EVENTS if self.owner == LEARNING else CURRICULUM_EVENTS
        if event_type not in allowed:
            self._deny("EVENT", event_type)
        return self.__repo.emit(event_type, subject_id, body)

    def count_objects(self, kind: str) -> int:
        if not self._allowed_object_kind(kind):
            raise AuthorityBoundaryError(f"FOREIGN_AUTHORITY_READ_REQUIRES_PORT:{self.owner}:OBJECT:{kind}")
        return self.__repo.count_objects(kind)
