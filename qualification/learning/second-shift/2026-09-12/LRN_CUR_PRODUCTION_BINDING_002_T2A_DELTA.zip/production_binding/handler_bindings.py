from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any, Callable, Dict, Mapping, Optional

from authority_boundary import CURRICULUM, LEARNING
from .master_core import MasterCoreRouteRegistry, RouteBindingError


class ExactHandlerContractError(ValueError):
    """Raised before domain mutation when an exact frozen route contract is violated."""


@dataclass(frozen=True)
class HandlerBindingStanding:
    interface_id: str
    canonical_owner: str
    state: str
    reason: str


def _strict_payload(payload: Mapping[str, Any], *, required: set[str], optional: set[str] = frozenset()) -> Dict[str, Any]:
    if not isinstance(payload, Mapping):
        raise ExactHandlerContractError("PAYLOAD_MUST_BE_OBJECT")
    keys = set(payload)
    missing = sorted(required - keys)
    unknown = sorted(keys - required - optional)
    if missing:
        raise ExactHandlerContractError("MISSING_REQUIRED_FIELDS:" + ",".join(missing))
    if unknown:
        raise ExactHandlerContractError("UNKNOWN_FIELDS:" + ",".join(unknown))
    return copy.deepcopy(dict(payload))


def _nonblank(value: Any, field: str) -> str:
    text = str(value).strip()
    if not text:
        raise ExactHandlerContractError(f"EMPTY_FIELD:{field}")
    return text


def build_pb002_tranche1_handlers(*, learning_runtime: Any, curriculum_query: Any) -> Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]]:
    """Materialize the first exact PB002 inbound handler tranche.

    This intentionally binds only interfaces whose current owner-separated runtime semantics
    match the frozen 001C route contract without inventing missing cross-domain/shared authority.
    Unlisted routes remain fail-closed in MasterCoreRouter.
    """

    def create_learning_goal(payload: Dict[str, Any]) -> Dict[str, Any]:
        p = _strict_payload(
            payload,
            required={"client_operation_id", "title", "objective", "horizon", "priority"},
        )
        return learning_runtime.register_goal(
            operation_id=_nonblank(p["client_operation_id"], "client_operation_id"),
            goal_id=f"LGOAL-{_nonblank(p['client_operation_id'], 'client_operation_id')}",
            title=_nonblank(p["title"], "title"),
            desired_outcome=_nonblank(p["objective"], "objective"),
            horizon=copy.deepcopy(p["horizon"]),
            priority=copy.deepcopy(p["priority"]),
        )

    def create_remediation_need(payload: Dict[str, Any]) -> Dict[str, Any]:
        p = _strict_payload(
            payload,
            required={"goal_id", "learner_ref", "skill_or_criterion_refs", "evidence_refs", "diagnosis_reason_codes", "client_operation_id"},
        )
        refs = p["skill_or_criterion_refs"]
        evidence = p["evidence_refs"]
        if not isinstance(refs, list) or not refs:
            raise ExactHandlerContractError("SKILL_OR_CRITERION_REFS_REQUIRED")
        if not isinstance(evidence, list) or not evidence:
            raise ExactHandlerContractError("EVIDENCE_REFS_REQUIRED")
        return learning_runtime.create_remediation_need_contract(
            operation_id=_nonblank(p["client_operation_id"], "client_operation_id"),
            goal_id=_nonblank(p["goal_id"], "goal_id"),
            learner_ref=copy.deepcopy(p["learner_ref"]),
            skill_or_criterion_refs=copy.deepcopy(refs),
            evidence_refs=copy.deepcopy(evidence),
            diagnosis_reason_codes=copy.deepcopy(p["diagnosis_reason_codes"]),
        )

    def get_curriculum(payload: Dict[str, Any]) -> Dict[str, Any]:
        p = _strict_payload(payload, required={"curriculum_id"}, optional={"version"})
        curriculum_id = _nonblank(p["curriculum_id"], "curriculum_id")
        version = int(p.get("version", 1))
        if version < 1:
            raise ExactHandlerContractError("CURRICULUM_VERSION_INVALID")
        course = curriculum_query.get_course(curriculum_id, version)
        return {
            "owner": CURRICULUM,
            "curriculum_id": curriculum_id,
            "version": version,
            "curriculum": copy.deepcopy(course),
        }

    return {
        "I001": create_learning_goal,
        "I016-L": create_remediation_need,
        "I027": get_curriculum,
    }


def evaluate_pb002_handler_coverage(
    registry: MasterCoreRouteRegistry,
    handlers: Mapping[str, Callable[[Dict[str, Any]], Dict[str, Any]]],
) -> Dict[str, Any]:
    inbound = [r for r in registry.all() if r.interface_type in {"COMMAND", "QUERY"}]
    domain = [r for r in inbound if r.canonical_owner in {LEARNING, CURRICULUM}]
    shared = [r for r in inbound if r.canonical_owner not in {LEARNING, CURRICULUM}]
    bound = []
    invalid = []
    for iid in sorted(handlers):
        try:
            route = registry.get(iid)
        except RouteBindingError:
            invalid.append(iid)
            continue
        if route.interface_type not in {"COMMAND", "QUERY"} or route.canonical_owner not in {LEARNING, CURRICULUM}:
            invalid.append(iid)
            continue
        bound.append(iid)
    if invalid:
        raise RouteBindingError("INVALID_DOMAIN_HANDLER_BINDINGS:" + ",".join(invalid))
    outstanding = [r.interface_id for r in domain if r.interface_id not in handlers]
    return {
        "objective": "LRN-CUR-PRODUCTION-BINDING-002",
        "tranche": "PB002-T1",
        "inbound_total": len(inbound),
        "domain_inbound_total": len(domain),
        "shared_inbound_total": len(shared),
        "exact_domain_handlers_bound": len(bound),
        "exact_domain_handlers_bound_ids": bound,
        "exact_domain_handlers_outstanding": len(outstanding),
        "exact_domain_handlers_outstanding_ids": outstanding,
        "production_complete": False,
        "truth_boundary": "T1 exact handlers only; all unlisted domain routes remain fail-closed and shared routes require canonical shared gateways.",
    }
