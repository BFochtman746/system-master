import json
import tempfile
import unittest
from pathlib import Path

from authority_boundary import CURRICULUM, LEARNING, OwnerScopedRepository, AuthorityBoundaryError
from curriculum_runtime.service import CurriculumQueryPort
from learning_runtime.service import LearningRuntime
from learning_lab.repository import Repository
from production_binding.handler_bindings import (
    ExactHandlerContractError,
    build_pb002_tranche1_handlers,
    evaluate_pb002_handler_coverage,
)
from production_binding.master_core import MasterCoreRouteRegistry, MasterCoreRouter, RouteBindingError
from shared_ports.codec import digest


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / 'production_binding' / 'MASTER_CORE_ROUTE_MANIFEST_001.json'


class AtomicPortableRepository(Repository):
    """Test-only stand-in for the already-tested Postgres atomic mutation contract."""
    def __init__(self, path):
        super().__init__(path)
        self.atomic_calls = 0

    def atomic_mutation(self, *, operation_id, payload, object_write, result, event=None):
        prior = self.operation_result(operation_id, payload)
        if prior is not None:
            return prior
        self.atomic_calls += 1
        self.put_object(object_write['kind'], object_write['object_id'], int(object_write['version']), object_write['body'])
        self.record_operation(operation_id, payload, result)
        if event:
            self.emit(event['event_type'], event['subject_id'], event['body'])
        return result


class PB002Tranche1Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.learning_raw = AtomicPortableRepository(str(Path(self.tmp.name) / 'learning.db'))
        self.curriculum_raw = AtomicPortableRepository(str(Path(self.tmp.name) / 'curriculum.db'))
        self.learning_repo = OwnerScopedRepository(self.learning_raw, LEARNING)
        self.curriculum_repo = OwnerScopedRepository(self.curriculum_raw, CURRICULUM)
        self.curriculum_query = CurriculumQueryPort(self.curriculum_repo)
        self.learning = LearningRuntime(self.learning_repo, self.curriculum_query)
        self.registry = MasterCoreRouteRegistry.from_manifest(MANIFEST)
        self.handlers = build_pb002_tranche1_handlers(learning_runtime=self.learning, curriculum_query=self.curriculum_query)
        self.router = MasterCoreRouter(self.registry, handlers=self.handlers)

    def tearDown(self):
        self.tmp.cleanup()

    def test_exact_coverage_is_truthful_and_bounded(self):
        report = evaluate_pb002_handler_coverage(self.registry, self.handlers)
        self.assertEqual(report['inbound_total'], 63)
        self.assertEqual(report['domain_inbound_total'], 59)
        self.assertEqual(report['shared_inbound_total'], 4)
        self.assertEqual(report['exact_domain_handlers_bound'], 3)
        self.assertEqual(report['exact_domain_handlers_bound_ids'], ['I001', 'I016-L', 'I027'])
        self.assertEqual(report['exact_domain_handlers_outstanding'], 56)
        self.assertFalse(report['production_complete'])

    def test_i001_create_learning_goal_uses_atomic_owner_scoped_mutation(self):
        payload = {'client_operation_id':'op-1','title':'SQL','objective':'query safely','horizon':'30d','priority':'HIGH'}
        result = self.router.dispatch('I001', payload)
        self.assertEqual(result['goal']['owner'], LEARNING)
        self.assertEqual(result['goal']['horizon'], '30d')
        self.assertEqual(result['goal']['priority'], 'HIGH')
        self.assertEqual(self.learning_raw.atomic_calls, 1)
        replay = self.router.dispatch('I001', payload)
        self.assertEqual(replay, result)
        self.assertEqual(self.learning_raw.atomic_calls, 1)

    def test_i001_same_operation_changed_payload_fails_closed(self):
        base = {'client_operation_id':'op-2','title':'SQL','objective':'query safely','horizon':'30d','priority':'HIGH'}
        self.router.dispatch('I001', base)
        changed = dict(base, objective='different')
        with self.assertRaisesRegex(ValueError, 'IDEMPOTENCY_DIGEST_MISMATCH'):
            self.router.dispatch('I001', changed)

    def test_i001_unknown_fields_are_rejected_before_mutation(self):
        payload = {'client_operation_id':'op-3','title':'SQL','objective':'query safely','horizon':'30d','priority':'HIGH','mastery':True}
        with self.assertRaisesRegex(ExactHandlerContractError, 'UNKNOWN_FIELDS:mastery'):
            self.router.dispatch('I001', payload)
        self.assertEqual(self.learning_raw.atomic_calls, 0)

    def test_i016l_creates_learning_owned_need_from_references_only(self):
        payload = {
            'goal_id':'G1',
            'learner_ref':{'learner_id':'L1'},
            'skill_or_criterion_refs':[{'skill_id':'S1'}],
            'evidence_refs':[{'evidence_ref':'E1'}],
            'diagnosis_reason_codes':['GAP'],
            'client_operation_id':'need-op-1',
        }
        result = self.router.dispatch('I016-L', payload)
        self.assertEqual(result['need']['owner'], LEARNING)
        self.assertEqual(result['need']['requested_outcome'], 'CURRICULUM_REMEDIATION_PLAN')
        self.assertEqual(result['need']['state'], 'OPEN')
        self.assertEqual(result['need']['learner_ref'], {'learner_id':'L1'})
        self.assertEqual(result['need']['diagnosis_reason_codes'], ['GAP'])
        self.assertNotIn('lesson', result['need'])
        self.assertNotIn('mastery', result['need'])
        self.assertEqual(self.learning_raw.atomic_calls, 1)

    def test_i016l_requires_evidence_references(self):
        payload = {'goal_id':'G1','learner_ref':{'learner_id':'L1'},'skill_or_criterion_refs':[{'skill_id':'S1'}],'evidence_refs':[],'diagnosis_reason_codes':['GAP'],'client_operation_id':'need-op-2'}
        with self.assertRaisesRegex(ExactHandlerContractError, 'EVIDENCE_REFS_REQUIRED'):
            self.router.dispatch('I016-L', payload)

    def test_i016l_uses_001c_semantic_signature_and_rejects_condensed_001d_aliases(self):
        exact = {
            'goal_id':'G2',
            'learner_ref':{'learner_id':'L2'},
            'skill_or_criterion_refs':[{'criterion_id':'CR1'}],
            'evidence_refs':[{'evidence_ref':'E2'}],
            'diagnosis_reason_codes':['WEAK_CRITERION'],
            'client_operation_id':'need-op-3',
        }
        result = self.router.dispatch('I016-L', exact)
        self.assertEqual(result['need']['learner_ref'], {'learner_id':'L2'})
        self.assertEqual(result['need']['diagnosis_reason_codes'], ['WEAK_CRITERION'])
        condensed = {
            'goal_id':'G3',
            'skill_or_criterion_refs':[{'skill_id':'S3'}],
            'evidence_refs':[{'evidence_ref':'E3'}],
            'diagnosis_reason':'GAP',
            'operation_id':'need-op-4',
        }
        with self.assertRaisesRegex(ExactHandlerContractError, 'MISSING_REQUIRED_FIELDS'):
            self.router.dispatch('I016-L', condensed)

    def test_i016l_requires_diagnosis_reason_codes_list(self):
        payload = {
            'goal_id':'G4','learner_ref':{'learner_id':'L4'},
            'skill_or_criterion_refs':[{'skill_id':'S4'}],
            'evidence_refs':[{'evidence_ref':'E4'}],
            'diagnosis_reason_codes':[],
            'client_operation_id':'need-op-5',
        }
        with self.assertRaisesRegex(ValueError, 'REMEDIATION_DIAGNOSIS_REASON_CODES_REQUIRED'):
            self.router.dispatch('I016-L', payload)

    def test_i027_get_curriculum_is_read_only_and_curriculum_owned(self):
        course = {'course_id':'C1','version':1,'skills':[],'criteria':[],'lessons':[],'items':[]}
        self.curriculum_repo.put_object('course', 'C1', 1, course)
        result = self.router.dispatch('I027', {'curriculum_id':'C1','version':1})
        self.assertEqual(result['owner'], CURRICULUM)
        self.assertEqual(result['curriculum'], course)
        self.assertEqual(self.curriculum_raw.atomic_calls, 0)

    def test_unbound_domain_route_still_fails_closed(self):
        with self.assertRaisesRegex(RouteBindingError, 'HANDLER_NOT_BOUND:I002'):
            self.router.dispatch('I002', {})

    def test_owner_scope_blocks_foreign_atomic_object(self):
        with self.assertRaisesRegex(AuthorityBoundaryError, 'FOREIGN_AUTHORITY_WRITE_BLOCKED'):
            self.learning_repo.atomic_mutation(
                operation_id='foreign', payload={},
                object_write={'kind':'course','object_id':'C1','version':1,'body':{}},
                result={}, event=None,
            )


if __name__ == '__main__':
    unittest.main()
